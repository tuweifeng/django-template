import numpy as np
import cv2
from moviepy.editor import VideoFileClip, AudioFileClip
import librosa

def normalize(data):
    _range = np.max(np.abs(data))
    return np.abs(data) / _range

i = 0

def rock(video, music, output):
    clip = VideoFileClip(video)

    offset = 0.4
    width, height = clip.size

    croped_width = int(width * (1-offset))
    croped_height = int(height * (1-offset))

    fps = 24
    # y, sr = librosa.load(music)

    circle = fps*2

    c = np.sin(np.linspace(0, 2*np.pi, fps*circle)) * (offset / 2)

    def shake(src:cv2.Mat):
        global i
        new_img = cv2.resize(src, dsize=None, fx=c[i%circle]+1, fy=c[i%circle]+1)
        i += 1
        h, w, d = new_img.shape

        left = (w - croped_width) // 2
        right = left + croped_width
        top = (h - croped_height) // 2
        bottom = top + croped_height
        return new_img[top:bottom, left:right]

    audioclip = AudioFileClip(music)
    clip = clip.set_duration(min(audioclip.duration, clip.duration))
    clip = clip.set_audio(audioclip)
    clip = clip.fl_image(image_func=shake)

    clip.write_videofile(output, fps=fps)


video = "./out1.mp4"
music = "/Users/tuweifeng/Desktop/音乐/电音/Inspire.m4a"
output = "./rock.mp4"
rock(video, music, output)