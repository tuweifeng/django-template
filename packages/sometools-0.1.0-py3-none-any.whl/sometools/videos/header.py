
from sometools import FONT_ZH
from moviepy.editor import CompositeVideoClip, VideoClip, TextClip, AudioClip


def add_header(clip: VideoClip, txt: str, duration: int, audioclip: AudioClip = None):
    fontsize = min(clip.size) // 5
    textclip = TextClip(
        txt=txt,
        size=clip.size,
        font=FONT_ZH,
        stroke_width=1,
        stroke_color="red",

        fontsize=fontsize,
        color="yellow",
        method="caption"
    )
    videoclip = CompositeVideoClip([textclip], size=clip.size)
    if audioclip:
        if not duration:
            # BUG 结尾有回音,去掉 0.2秒
            duration = audioclip.duration - 0.2
        videoclip = videoclip.set_audio(audioclip)

    videoclip = videoclip.set_fps(1).set_duration(duration)
    return videoclip
