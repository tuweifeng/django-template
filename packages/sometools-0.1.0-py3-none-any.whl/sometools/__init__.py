
import os

BASE_DIR = os.path.dirname(
 os.path.realpath(__file__)
)
STATIC_ROOT = os.path.join(BASE_DIR, "static")

FONT_ZH = os.path.join(STATIC_ROOT, "zh.ttf")
