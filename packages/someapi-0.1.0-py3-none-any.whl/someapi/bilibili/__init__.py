from types import MappingProxyType

HEADERS = MappingProxyType({
    "origin": "https://www.bilibili.com",
    "referer": "https://www.bilibili.com/video/BV1iK411i7we/?spm_id_from=333.1007.tianma.1-1-1.click&vd_source=757531d6b126670d71e42bf9d8793271",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
})
